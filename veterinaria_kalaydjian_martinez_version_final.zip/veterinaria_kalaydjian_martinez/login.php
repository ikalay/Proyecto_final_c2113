<?php require_once("connection.php");?>

<?php require_once("head.php");?>

<?php require_once("header.php");?>
    <center>
        <h1 class="mb-2 py-5">Bienvenidos!</h1>

        <div class="md-flex ">
            <a href="loginUsuario.php" class="btn btn-primary btn col-2">Soy Cliente</a>
            <a href="loginCliente.php" class="btn btn-primary btn col-2">Administrador</a>
            </div>
        <p class="mt-5 mb-1 text-muted"></a>Ignacio Kalaydjian M</a>| &copy; 2021-2022</p>


        </div>

    </center>
