<?php

$mysqli = new mysqli("127.0.0.1", "root", "", "veterinaria2", 3306);
if ($mysqli->connect_errno) {
echo "Hubo un error: " . $mysqli->connect_error. " " . $mysqli->connect_error;
}

echo $mysqli->host_info . "\n";

?>