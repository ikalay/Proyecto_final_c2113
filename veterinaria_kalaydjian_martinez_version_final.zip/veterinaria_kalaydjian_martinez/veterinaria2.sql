-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 29-07-2021 a las 23:22:28
-- Versión del servidor: 10.4.19-MariaDB
-- Versión de PHP: 8.0.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `veterinaria2`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `clientes`
--

CREATE TABLE `clientes` (
  `idCliente` int(40) NOT NULL,
  `nombre` varchar(40) COLLATE utf8mb4_spanish_ci NOT NULL,
  `apellido` varchar(40) COLLATE utf8mb4_spanish_ci NOT NULL,
  `email` varchar(40) COLLATE utf8mb4_spanish_ci NOT NULL,
  `direccion` varchar(40) COLLATE utf8mb4_spanish_ci NOT NULL,
  `nombreMascota` varchar(40) COLLATE utf8mb4_spanish_ci NOT NULL,
  `descripcionTarea` varchar(40) COLLATE utf8mb4_spanish_ci NOT NULL,
  `residencia` varchar(40) COLLATE utf8mb4_spanish_ci NOT NULL,
  `tipoMascota` varchar(40) COLLATE utf8mb4_spanish_ci NOT NULL,
  `turnoTarea` varchar(40) COLLATE utf8mb4_spanish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;

--
-- Volcado de datos para la tabla `clientes`
--

INSERT INTO `clientes` (`idCliente`, `nombre`, `apellido`, `email`, `direccion`, `nombreMascota`, `descripcionTarea`, `residencia`, `tipoMascota`, `turnoTarea`) VALUES
(1, 'Marcos', 'Pena', 'prueba@gmail.com', 'Callao', 'oscar', 'fdsfsdfsfsddddddddd', 'Buenos Aires Provincia', 'Perro', 'Mañana'),
(2, 'Mateo', 'Rodriguez', 'litto@gmail.com', 'Arenales 1979', 'mapo', 'ddaaasad', 'Buenos Aires Provincia', 'Gato', 'Tarde/Noche'),
(3, 'Gustavo', 'Perez', 'perez@hotmail.com', 'Arenales 2079', 'fito', 'Corte', 'Buenos Aires Provincia', 'Gato', 'Mañana'),
(4, 'Mauro', 'Sergio', 'reactor82@hotmail.com', 'Arenales 2000', 'litto', 'Corte y Lavado', 'Buenos Aires Provincia', 'Perro', 'Mañana'),
(5, 'Mateo', 'Rodriguez', 'litto@gmail.com', 'Arenales 1979', 'tito', 'Productos', 'Buenos Aires Capital', 'Otro', 'Tarde/Noche'),
(6, 'Mateo', 'Funes', 'funes@gmail.com', 'Arenales 1979', 'beto', 'Corte', 'Buenos Aires Provincia', 'Gato', 'Tarde/Noche'),
(7, 'Marcos', 'Galvez', 'prueba@gmail.com', 'Callao', 'futi', 'Corte', 'Buenos Aires Capital', 'Gato', 'Tarde/Noche');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios`
--

CREATE TABLE `usuarios` (
  `idUsuario` varchar(40) NOT NULL,
  `usuario` varchar(40) NOT NULL,
  `clave` varchar(40) NOT NULL,
  `nombreyapellido` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `usuarios`
--

INSERT INTO `usuarios` (`idUsuario`, `usuario`, `clave`, `nombreyapellido`) VALUES
('1', 'root@gmail.com', '123456', 'Ignacio Martinez');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `clientes`
--
ALTER TABLE `clientes`
  ADD PRIMARY KEY (`idCliente`);

--
-- Indices de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`idUsuario`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `clientes`
--
ALTER TABLE `clientes`
  MODIFY `idCliente` int(40) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
