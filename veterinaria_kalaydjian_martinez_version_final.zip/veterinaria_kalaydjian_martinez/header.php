<header>
      <nav class="navbar navbar-expand-lg navbar-light bg-light fixed-top bg-dark">
            <div class="container-fluid">
              <a class="navbar-brand justify-content-end" href="index.html"><h1>veterinaria</h1></a>
              <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
              <span class="navbar-toggler-icon"></span>
              </button>
              <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav justify-content-end">
                  <li class="nav-item">

                    <a  href="index.html" class="nav-link active" > | Nosotros  <i class=""></i> </a>

                  </li>
                  
                  <li class="nav-item">

                    <a  href="index.html" class="nav-link active" >| Servicios <i class=""></i> </a>

                  </li>

                  <li class="nav-item">

                    <a  href="registroMascota.php" class="nav-link active" >| Registrate <i class=""></i> </a>

                  </li>

                  <li class="nav-item">
             
                    <a  href="index.html" class="nav-link active" >| Contacto <i class="far fa-envelope"></i> </a>

                  </li>

                  <li class="nav-item">

                    <a  href="login.php" class="nav-link active" > | Login <i class=""></i> </a>

                  </li>

                </ul>
              </div>
            </div>
          </nav>
        
      </header>