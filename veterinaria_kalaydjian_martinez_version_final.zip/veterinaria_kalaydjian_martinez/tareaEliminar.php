

<?php 
require_once("head.php");

require_once("header.php");

include "funciones.php";
$link_db = conexionDB();
	
$id_cliente = $_REQUEST['id'];
$query = "SELECT * FROM clientes WHERE idCliente=$id_cliente";
$result = mysqli_query($link_db,$query);

//	EL MÉTODO mysqli_fetch_assoc() ES IDEAL PARA OBTENER 1 SOLO REGISTRO Y NO IMPLEMENTAR UN BUCLE
$registro = mysqli_fetch_assoc($result);

?>
<html>
	<head>
		<meta charset="utf-8">
        <br>
        <br>
        <br>
	</head>

	<body>
		<h3>Eliminar Cliente de la Base de datos</h3>
	  	
	  	<form action="operaciones_db.php" method="post">
		  	<!-- TYPE HIDDEN ENVÍA DATOS OCULTOS -->
		  	<input type="hidden" name="tipo_operacion" value="eliminar">
		  	<!-- ENVIO EL ID PARA EL WHERE DEL UPDATE -->
			<input type="hidden" name="id" value="<?php echo $registro['idCliente'];?>">

		  	<p>Nombre: <input type="text" name="nombre" size="40" required value="<?php echo $registro['nombre'];?>"></p>
			<p>Apellido: <input type="text" name="apellido" size="40" required value="<?php echo $registro['apellido'];?>"></p>
		  	<p>Email: <input type="text" name="email" size="40" required value="<?php echo $registro['email'];?>"></p>
		  	<p>Direccion: <input type="text" name="direccion" size="40" required value="<?php echo $registro['direccion'];?>"></p>
			<p>Mascota: <input type="text" name="nombreMascota" size="40" required value="<?php echo $registro['nombreMascota'];?>"></p>
		  	<p>Servicio Asignado: <input type="text" name="descripcionTarea" value="<?php echo $registro['descripcionTarea'];?>"></p>
			<p>Residencia: <input type="text" name="residencia" value="<?php echo $registro['residencia'];?>"></p>
			<p>Tipo Mascota: <input type="text" name="tipoMascota" value="<?php echo $registro['tipoMascota'];?>"></p>
			<p>Turno: <input type="text" name="turnoTarea" value="<?php echo $registro['turnoTarea'];?>"></p>

		  	<p>
		    	<input type="submit" value="Eliminar">
		    	<input type="reset" value="Resetar campos">
		  	</p>
		</form>

	  	<p><a href="adminCliente.php">Volver a mi sistema de Tareas</a></p>
	</body>
</html>