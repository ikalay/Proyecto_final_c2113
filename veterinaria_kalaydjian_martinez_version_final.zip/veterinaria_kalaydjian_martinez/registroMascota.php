<?php include "funciones.php"; ?>

<?php require_once("connection.php");?>

<?php require_once("head.php");?>

<?php require_once("header.php");?>

<!doctype html>
<html lang="es">

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <meta name="generator" content="">
    <title>Registro de Usuarios Nuevos</title>

    <!-- Bootstrap core de CSS -->
	<link href="./css/bootstrap.min.css" rel="stylesheet">


    <style>
      .bd-placeholder-img {
        font-size: 1.125rem;
        text-anchor: middle;
        -webkit-user-select: none;
        -moz-user-select: none;
        -ms-user-select: none;
        user-select: none;
      }

      @media (min-width: 768px) {
        .bd-placeholder-img-lg {
          font-size: 3.5rem;
        }
      }
    </style>

    <!-- Customizacion del estilo de css brindado con la libreria de BS -->
    <link href="./css/form-validation.css" rel="stylesheet">
</head>


<body class="bg-light">

<center>
  
  <div class="py-5 text-center">
    <img class="d-block mx-auto mb-4" src="./img/usuarios.jpg" alt="" width="102" height="102">
    <h2>Formulario de Registro de nuevo usuario</h2>
    <p class="lead">El usario será confirmado por el Administrador del Sistema.</p>
  </div>

    <div class="col-md-12  text-center">
      <h4 class="mb-3">Usuario</h4>

        <!-- Aqui comienza mi Formulario 	
                <button class="btn btn-danger btn-lg btn-block"  value="Enviar" type="submit">Enviar</button>
        <button class="btn btn-danger btn-lg btn-block"  value="Borrar" type="reset">Borrar</button>
        -->

        <form  class="needs-validation" novalidate action="operaciones_db.php" method="post">
        <input type="hidden" name="tipo_operacion" value="agregar"></p>


        <input type="hidden" name="idCliente" value=""></p>
        
        <div class="row">
          <div class="col-md-6 mb-3">
            Nombre: <input type="text" class="form-control" placeholder="Tu nombre" name="nombre" value="" /><br>
            <div class="invalid-feedback">
              Faltó ingresar el nombre.
            </div>
        </div>

          <div class="col-md-6 mb-3">
            Apellido: <input type="text" class="form-control" placeholder="Tu apellido" name="apellido" value="" /><br>
            <div class="invalid-feedback">
              Faltó ingresar el apellido.
            </div>
          </div>
        </div>

        <div class="mb-3">
          Email: <input type="text" class="form-control" placeholder="tumail@gmail.com" name="email" value="" /><br>
          <div class="invalid-feedback">
            El Email parece inválido.
          </div>
        </div>

        <div class="mb-3">
            Direccion: <input type="text" class="form-control" placeholder="Calle, n°, localidad..." name="direccion" value="" /><br>
          <div class="invalid-feedback">
            Faltó ingresar el domicilio.
          </div>
        </div>

        <div class="mb-3">
            Nombre Mascota: <input type="text" class="form-control" placeholder="Mascota" name="nombreMascota" value="" /><br>
            <div class="invalid-feedback" style="width: 100%;">
              Faltó ingresar nombre de mascota.
            </div>
        </div>

        <label for="state">Servicio para tu mascota</label>
            <select class="custom-select d-block w-100" input type="text" name="descripcionTarea" value="" style="width: 100px;">>
              <option value="">Seleccioná...</option>
              <option>Chequeo General</option>
              <option>Vacunacion</option>
              <option>Corte</option>	
              <option>Corte y Lavado</option>	
              <option>Productos</option>
            </select>
            <div class="invalid-feedback">
              Seleccioná una opcion válida.
            </div>
          </div>


<br>
        <div class="col-md-5 mb-3">
            <label for="state">Lugar de residencia</label>
            <select class="custom-select d-block w-100" input type="text" name="residencia" value="" >
              <option value="">Seleccioná...</option>
              <option>Buenos Aires Provincia</option>
              <option>Buenos Aires Capital</option>			  
            </select>
            <div class="invalid-feedback">
              Seleccioná una localidad válida.
            </div>
          </div>

        <div class="row">
          <div class="col-md-5 mb-3">
            <label for="country">Mascota</label>
            <select class="custom-select d-block w-100" input type="text" name="tipoMascota" value="">
              <option value="">Seleccioná...</option>
              <option>Perro</option>
              <option>Gato</option>
              <option>Otro</option>
            </select>
            <div class="invalid-feedback">
              Seleccioná una opcion válida.
            </div>
          </div>
        </div>

        <div class="row">
            <div class="col-md-5 mb-3">
              <label for="state">Turno</label>
              <select class="custom-select d-block w-100" input type="text" name="turnoTarea" value="" >
                <option value="">Seleccioná...</option>
                <option>Mañana</option>
                <option>Tarde/Noche</option>			  
              </select>
              <div class="invalid-feedback">
                Seleccioná un turno valido. El mismo te será confirmado por Email.
              </div>
            </div>
		  </div>
      </center>

    <button class="btn btn-danger btn-lg btn-block"  value="Enviar" type="submit">Enviar</button>
    <button class="btn btn-danger btn-lg btn-block"  value="Borrar" type="reset">Borrar</button>

</form>

<footer class="my-5 pt-5 text-muted text-center text-small">
	<p class="mb-1"></a>Ignacio Kalaydjian M</a>| &copy; 2021-2022</p>

</footer>

	<script src="./js/jquery.js"></script>
    <script src="./js/form-validation.js"></script></body>

</html>
