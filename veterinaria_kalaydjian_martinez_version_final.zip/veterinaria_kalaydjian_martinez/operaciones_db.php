<?php

require_once("connection.php");

require_once("head.php");

require_once("header.php");

include "funciones.php";

$link_db = conexionDB();
//	SEGÚN EL VALOR tipo_operacion VERIFICO QUE OPERACIÓN HACER
$tipo = $_REQUEST['tipo_operacion'];

//	INSERT TAREA
if ($tipo == "agregar") {
    
    $nom = $_REQUEST['nombre'];
    $ape = $_REQUEST['apellido'];
    $ema = $_REQUEST['email'];
    $dir = $_REQUEST['direccion'];
    $nmas = $_REQUEST['nombreMascota'];
    $dt = $_REQUEST['descripcionTarea'];
    $resi = $_REQUEST['residencia'];
    $tipom = $_REQUEST['tipoMascota'];
    $ttar = $_REQUEST['turnoTarea'];


    $resultado = insertDB($link_db, $nom, $ape, $ema, $dir, $nmas, $dt, $resi, $tipom, $ttar);

    echo '<p><a href="registroMascota.php">Volver al Formulario</a></p>';
}

//	UPDATE
if ($tipo == "editar") {

    $id = $_REQUEST['id'];
    $nom = $_REQUEST['nombre'];
    $ape = $_REQUEST['apellido'];
    $ema = $_REQUEST['email'];
    $dir = $_REQUEST['direccion'];
    $nmas = $_REQUEST['nombreMascota'];
    $dt = $_REQUEST['descripcionTarea'];
    $resi = $_REQUEST['residencia'];
    $tipom = $_REQUEST['tipoMascota'];
    $ttar = $_REQUEST['turnoTarea'];


    $resultado = updateDB($link_db, $id, $nom, $ape, $ema, $dir, $nmas, $dt, $resi, $tipom, $ttar);

    echo 'el cliente fue eliminado';
    print '<pre>';
    print_r($_REQUEST);
    print '</pre>';
    echo '<p><a href="adminCliente.php">Volver al Inicio</a></p>';

}

//	DELETE
if ($tipo == "eliminar") {

    $id = $_REQUEST['idCliente'];
    $nom = $_REQUEST['nombre'];
    $ape = $_REQUEST['apellido'];
    $ema = $_REQUEST['email'];
    $dir = $_REQUEST['direccion'];
    $nmas = $_REQUEST['nombreMascota'];
    $dt = $_REQUEST['descripcionTarea'];
    $resi = $_REQUEST['residencia'];
    $tipom = $_REQUEST['tipoMascota'];
    $ttar = $_REQUEST['turnoTarea'];


    $resultado = deleteDB($link_db, $id, $nom, $ape, $ema, $dir, $nmas, $dt, $resi, $tipom, $ttar);

    echo 'el cliente fue eliminado';
    print '<pre>';
    print_r($_REQUEST);
    print '</pre>';
    //echo '<p><a href="adminCliente.php">Volver al Inicio</a></p>';
}
?>
<a href="adminCliente.php" class="btn btn-primary btn col-2">Desconectarse</a>

